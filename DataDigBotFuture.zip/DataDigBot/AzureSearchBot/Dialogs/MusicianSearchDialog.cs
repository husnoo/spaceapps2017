﻿using System;
using System.Threading.Tasks;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using AzureSearchBot.Services;
using AzureSearchBot.Model;
using System.Diagnostics;
using AzureSearchBot.Util;
using System.Collections.Generic;

namespace AzureSearchBot.Dialogs
{
    [Serializable]
    public class MusicianSearchDialog : IDialog<object>
    {
        private readonly AzureSearchService searchService = new AzureSearchService();
        private const string BioSphere = "BioSphere = 7";
        private const string LandSurface = "Land Surface = 64";
        private const string SolidEarth = "Solid Earth = 3";

        private const string HeroCard = "Hero card";
        private const string ThumbnailCard = "Thumbnail card";
        private const string ReceiptCard = "Receipt card";
        private const string SigninCard = "Sign-in card";
        private const string AnimationCard = "Animation card";
        private const string VideoCard = "Video card";
        private const string AudioCard = "Audio card";

        private IEnumerable<string> options = new List<string> { HeroCard, ThumbnailCard, ReceiptCard, SigninCard, AnimationCard, VideoCard, AudioCard };
        public async Task StartAsync(IDialogContext context)
        {
            await context.PostAsync("That's fine, I have 17943 near real-time datasets, would you like to narrow it down by location?");
            context.Wait(MessageRecievedAsync);
        }

        public virtual async Task MessageRecievedAsync(IDialogContext context, IAwaitable<IMessageActivity> result)
        {
            //var message = await result;
            try
            {
                //    SearchResult searchResult = await searchService.SearchByName(message.Text);
                //    if(searchResult.value.Length != 0)
                //    {
                //        CardUtil.showHeroCard(message, searchResult);
                //    }
                //    else{
                //PromptDialog.Text(context, this.MenuSelection, "That's fine, I have 17943 near real-time datasets, would you like to narrow it down by location?");

                //PromptDialog.Choice(context, this.AfterMenuSelection, new List<string>() { ExplorerOption, SearchOption }, "Welcome to the DigData Chat bot, I have got wealth of information, Which area I can help you with...?");
                //}
                var selectedCard = await result;

                var message = context.MakeMessage();

                var attachment = GetSelectedCard(SigninCard);
                message.Attachments.Add(attachment);

                await context.PostAsync(message);

               context.Wait(AfterMenuSelection);
            }
            catch(Exception e)
            {
                Debug.WriteLine($"Error when searching for musician: {e.Message}");
            }
       
        }

        private async Task MenuSelection(IDialogContext context, IAwaitable<string> result)
        {
            var optionSelected = await result;
            string selectedEra = optionSelected.Split(' ')[0];

            try
            {
                //SearchResult searchResult = await searchService.SearchByEra(selectedEra);
                //if(searchResult.value.Length != 0)
                //{
                //    CardUtil.showHeroCard((IMessageActivity)context.Activity, searchResult);
                //}
                //else
                //{


                //PromptDialog.Choice<String>(context, this.AfterMenuSelection, , "That's fine, I have got 74 datasets please select the appropriate to see more...");
                //}
            }
            catch (Exception e)
            {
                Debug.WriteLine($"Error when filtering by genre: {e}");
            }
            
        }

        private async Task AfterMenuSelection(IDialogContext context, IAwaitable<IMessageActivity> result)
        {
           // var optionSelected = await result;
            //string selectedEra = optionSelected.Split(' ')[0];

            try
            {

                var selectedCard = await result;

                var message = context.MakeMessage();

                var attachment = GetSelectedCard(HeroCard);
                message.Attachments.Add(attachment);

                await context.PostAsync(message);

               // context.Wait(MessageRecievedAsync);
            }
            catch (Exception e)
            {
                Debug.WriteLine($"Error when filtering by genre: {e}");
            }
            
        }


        //This function is called after each dialog process is done
        private async Task ResumeAfterOptionDialog(IDialogContext context, IAwaitable<object> result)
        {
            //This means  MessageRecievedAsync function of this dialog (PromptButtonsDialog) will receive users' messeges
            context.Wait(MessageRecievedAsync);
        }

        //public virtual async Task DisplaySelectedCard(IDialogContext context, IAwaitable<string> result)
        //{
        //    var selectedCard = await result;

        //    var message = context.MakeMessage();

        //    var attachment = GetSelectedCard(selectedCard);
        //    message.Attachments.Add(attachment);

        //    await context.PostAsync(message);

        //    context.Wait(AfterMenuSelection);
        //}

        private static Attachment GetSelectedCard(string selectedCard)
        {
            switch (selectedCard)
            {
                
                case SigninCard:
                    return GetSigninCard();
           

                default:
                    return GetHeroCard();
            }
        }

        private static Attachment GetHeroCard()
        {
            var signinCard = new SigninCard
            {
                Text = "That's fine, I have got 74 datasets please select the appropriate to see more...",
                Buttons = new List<CardAction> { new CardAction(ActionTypes.OpenUrl, "Atmospheric Chemistry = 4", value: "https://login.microsoftonline.com/"), new CardAction(ActionTypes.OpenUrl, "Atmospheric Pressure = 2", value: "https://login.microsoftonline.com/"), new CardAction(ActionTypes.OpenUrl, "Atmospheric Winds = 1", value: "https://na01.safelinks.protection.outlook.com/?url=http%3A%2F%2Fwww.metoffice.gov.uk%2Fpublic%2Fweather%2Fforecast%2Fmap%2Fgcj2x8gt4%23%3Fzoom%3D9%26map%3DWind%26lon%3D-3.53%26lat%3D50.72%26fcTime%3D1493445600&data=02%7C01%7Calraza%40microsoft.com%7C49b086e2be5e44b51a0708d48f62520a%7C72f988bf86f141af91ab2d7cd011db47%7C1%7C0%7C636291099822669486&sdata=kmkenodAx63W5rZvdohk7CMGqhiHEmTarx%2FGcvRA1Rk%3D&reserved=0") }
            };

            return signinCard.ToAttachment();
        }


        private static Attachment GetSigninCard()
        {
            var signinCard = new SigninCard
            {
                Text = "That's fine, I have got 74 datasets please select the appropriate to see more...",
                Buttons = new List<CardAction> { new CardAction(ActionTypes.OpenUrl, "Atmosphere = 7", value: "https://login.microsoftonline.com/"), new CardAction(ActionTypes.OpenUrl, "Land Surface = 64", value: "https://login.microsoftonline.com/"), new CardAction(ActionTypes.OpenUrl, "Solid Earth = 3", value: "https://login.microsoftonline.com/") }
            };

            return signinCard.ToAttachment();
        }
    }
}

