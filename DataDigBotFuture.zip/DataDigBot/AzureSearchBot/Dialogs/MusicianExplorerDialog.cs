﻿using System;
using System.Threading.Tasks;
using Microsoft.Bot.Builder.Dialogs;
using AzureSearchBot.Services;
using Microsoft.Bot.Connector;
using System.Diagnostics;
using AzureSearchBot.Model;
using System.Collections.Generic;
using AzureSearchBot.Util;

namespace AzureSearchBot.Dialogs
{
    [Serializable]
    public class MusicianExplorerDialog : IDialog<object>
    {
        private readonly AzureSearchService searchService = new AzureSearchService();

        private const string HeroCard = "Hero card";
        private const string ThumbnailCard = "Thumbnail card";
        private const string ReceiptCard = "Receipt card";
        private const string SigninCard = "Sign-in card";
        private const string AnimationCard = "Animation card";
        private const string VideoCard = "Video card";
        private const string AudioCard = "Audio card";

        public async Task StartAsync(IDialogContext context)
        {
            try
            {
                await context.PostAsync($"What's on your mind?");
                context.Wait(this.MessageRecievedAsync);
                //}
            }
            catch (Exception e)
            {
                Debug.WriteLine($"Error when faceting by era: {e}");
            }
        }

        public virtual async Task MessageRecievedAsync(IDialogContext context, IAwaitable<IMessageActivity> result)
        {
            //Show options whatever users chat
            PromptDialog.Text(context, this.AfterMenuSelection, "Exeter is nice I have got 6,998 data sets for the area, are you interested anything specific about exter?");
        }
        private async Task AfterMenuSelection(IDialogContext context, IAwaitable<string> result)
        {
            var optionSelected = await result;
            string selectedEra = optionSelected.Split(' ')[0];

            try
            {
                //SearchResult searchResult = await searchService.SearchByEra(selectedEra);
                //if(searchResult.value.Length != 0)
                //{
                //    CardUtil.showHeroCard((IMessageActivity)context.Activity, searchResult);
                //}
                //else
                //{
                var selectedCard = await result;

                var message = context.MakeMessage();

                var attachment = GetSelectedCard(HeroCard);
                message.Attachments.Add(attachment);

                await context.PostAsync(message);
                //    await context.PostAsync($"I have 13 data sets in this case and the one interesting to you might be the flooding data set i.e......");
                //}
            }
            catch(Exception e)
            {
                Debug.WriteLine($"Error when filtering by genre: {e}");
            }
            context.Done<object>(null);
        }

        //This function is called after each dialog process is done
        private async Task ResumeAfterOptionDialog(IDialogContext context, IAwaitable<object> result)
        {
            //This means  MessageRecievedAsync function of this dialog (PromptButtonsDialog) will receive users' messeges
            context.Wait(MessageRecievedAsync);
        }

        private static Attachment GetSelectedCard(string selectedCard)
        {
            switch (selectedCard)
            {

                case SigninCard:
                    return GetSigninCard();


                default:
                    return GetHeroCard();
            }
        }

        private static Attachment GetHeroCard()
        {
            var signinCard = new SigninCard
            {
                Text = "I have 13 data sets in this case and the one interesting to you might be the flooding data set.",
                Buttons = new List<CardAction> { new CardAction(ActionTypes.OpenUrl, "Flooding Data Sets", value: "http://sedac.ciesin.columbia.edu/data/set/gpw-v4-population-density-adjusted-to-2015-unwpp-country-totals") }
            };

            return signinCard.ToAttachment();
        }


        private static Attachment GetSigninCard()
        {
            var signinCard = new SigninCard
            {
                Text = "That's fine, I have got 74 datasets please select the appropriate to see more...",
                Buttons = new List<CardAction> { new CardAction(ActionTypes.OpenUrl, "BioSphere = 7", value: "https://login.microsoftonline.com/"), new CardAction(ActionTypes.OpenUrl, "Land Surface = 64", value: "https://login.microsoftonline.com/"), new CardAction(ActionTypes.OpenUrl, "Solid Earth = 3", value: "https://login.microsoftonline.com/") }
            };

            return signinCard.ToAttachment();
        }
    }
}