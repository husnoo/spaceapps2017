﻿using System;
using System.Threading.Tasks;
using Microsoft.Bot.Builder.Dialogs;
using AzureSearchBot.Services;
using Microsoft.Bot.Connector;
using System.Diagnostics;
using AzureSearchBot.Model;
using System.Collections.Generic;
using AzureSearchBot.Util;

namespace AzureSearchBot.Dialogs
{
    [Serializable]
    public class MusicianExplorerDialog : IDialog<object>
    {
        private readonly AzureSearchService searchService = new AzureSearchService();

        private const string HeroCard = "Hero card";
        private const string ThumbnailCard = "Thumbnail card";
        private const string ReceiptCard = "Receipt card";
        private const string SigninCard = "Sign-in card";
        private const string AnimationCard = "Animation card";
        private const string VideoCard = "Video card";
        private const string AudioCard = "Audio card";

        public async Task StartAsync(IDialogContext context)
        {
            try
            {
                //FacetResult facetResult = await searchService.FetchFacets();
                //if (facetResult.searchfacets.Era.Length != 0)
                //{
                //    List<string> eras = new List<string>();
                //    foreach (Era era in facetResult.searchfacets.Era)
                //    {
                //        eras.Add($"{era.value} ({era.count})");
                //    }
                //    PromptDialog.Choice(context, AfterMenuSelection, eras, "Which era of music are you interested in?");
                //}
                //else
                //{

                //PromptDialog.Text(context, this.MessageRecievedAsync, "Exeter is nice I have got 6,998 data sets for the area, are you interested anything specific about exter?");
               // await context.PostAsync($"Welcome to the DigData Chat bot, I have got wealth of information, What's on your mind today?");
                context.Wait(MessageRecievedAsync);
                //}
            }
            catch (Exception e)
            {
                Debug.WriteLine($"Error when faceting by era: {e}");
            }
        }

        public virtual async Task MessageRecievedAsync(IDialogContext context, IAwaitable<IMessageActivity> result)
        {
            ////Show options whatever users chat
            //var selectedCard = await result;

            //var message = context.MakeMessage();

            //var attachment = GetSelectedCard(SigninCard);
            //message.Attachments.Add(attachment);

            //await context.PostAsync(message);

          //  await context.PostAsync($"You appear to be in Exeter, high tide is at 5.30pm today, and the weather in the south west is going to be Sunny. Enjoy surfing...");
          PromptDialog.Text(context, this.AfterMenuSelection, "Welcome to the DigData Chat bot, I have got wealth of information, What's on your mind today?");
        }
        private async Task AfterMenuSelection(IDialogContext context, IAwaitable<string> result)
        {
            var optionSelected = await result;
            string selectedEra = optionSelected.Split(' ')[0];

            try
            {
                //SearchResult searchResult = await searchService.SearchByEra(selectedEra);
                //if(searchResult.value.Length != 0)
                //{
                //    CardUtil.showHeroCard((IMessageActivity)context.Activity, searchResult);
                //}
                //else
                //{
                var selectedCard = await result;

                var message = context.MakeMessage();

                var attachment = GetSelectedCard(SigninCard);
                message.Attachments.Add(attachment);

                await context.PostAsync(message);
                //    await context.PostAsync($"I have 13 data sets in this case and the one interesting to you might be the flooding data set i.e......");
                //}
            }
            catch (Exception e)
            {
                Debug.WriteLine($"Error when filtering by genre: {e}");
            }
            context.Done<object>(null);
        }

        //This function is called after each dialog process is done
        private async Task ResumeAfterOptionDialog(IDialogContext context, IAwaitable<object> result)
        {
            //This means  MessageRecievedAsync function of this dialog (PromptButtonsDialog) will receive users' messeges
            context.Wait(MessageRecievedAsync);
        }

        private static Attachment GetSelectedCard(string selectedCard)
        {
            switch (selectedCard)
            {

                case SigninCard:
                    return GetSigninCard();


                default:
                    return GetHeroCard();
            }
        }

        private static Attachment GetHeroCard()
        {
            var signinCard = new SigninCard
            {
                Text = "I have 13 data sets in this case and the one interesting to you might be the flooding data set.",
                Buttons = new List<CardAction> { new CardAction(ActionTypes.OpenUrl, "Flooding Data Sets", value: "http://sedac.ciesin.columbia.edu/data/set/gpw-v4-population-density-adjusted-to-2015-unwpp-country-totals") }
            };

            return signinCard.ToAttachment();
        }


        private static Attachment GetSigninCard()
        {
            var signinCard = new SigninCard
            {
                Text = "You appear to be in Exeter, high tide is at 5.30pm today, and the weather in the south west is going to be Sunny. Enjoy surfing...",
                Buttons = new List<CardAction> { new CardAction(ActionTypes.OpenUrl, "Weather", value: "https://na01.safelinks.protection.outlook.com/?url=http%3A%2F%2Fwww.metoffice.gov.uk%2Fpublic%2Fweather%2Fforecast%2Fmap%2Fgcj2x8gt4%23%3Fzoom%3D9%26map%3DWind%26lon%3D-3.53%26lat%3D50.72%26fcTime%3D1493445600&data=02%7C01%7Calraza%40microsoft.com%7C49b086e2be5e44b51a0708d48f62520a%7C72f988bf86f141af91ab2d7cd011db47%7C1%7C0%7C636291099822669486&sdata=kmkenodAx63W5rZvdohk7CMGqhiHEmTarx%2FGcvRA1Rk%3D&reserved=0") }
            };

            return signinCard.ToAttachment();
        }
    }
}